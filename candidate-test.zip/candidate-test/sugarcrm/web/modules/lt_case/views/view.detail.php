<?php 

use Module\Views\Detail;

class CaseDetailView extends Detail {

    //
}
