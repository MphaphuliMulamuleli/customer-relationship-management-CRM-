<?php 

use Module\Views\Edit;

class CaseEditView extends Edit {

    //
}
