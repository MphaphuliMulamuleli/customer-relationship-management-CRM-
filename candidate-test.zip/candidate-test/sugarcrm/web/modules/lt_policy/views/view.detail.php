<?php 

use Module\Views\Detail;

class PolicyDetailView extends Detail {

    //
}
