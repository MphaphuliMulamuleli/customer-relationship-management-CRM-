<?php 

use Module\Views\Detail;

class CustomerDetailView extends Detail {

    //
}
