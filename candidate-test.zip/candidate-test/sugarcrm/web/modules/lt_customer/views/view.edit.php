<?php 

use Module\Views\Edit;

class CustomerEditView extends Edit {

    //
}
