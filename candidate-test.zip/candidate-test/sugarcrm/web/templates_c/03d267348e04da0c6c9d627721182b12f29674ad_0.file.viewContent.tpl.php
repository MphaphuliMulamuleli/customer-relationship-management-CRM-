<?php
/* Smarty version 4.3.4, created on 2023-10-07 17:14:48
  from '/var/www/sugarcrm/core/general/module/views/templates/viewContent.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6521920883d177_93005213',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '03d267348e04da0c6c9d627721182b12f29674ad' => 
    array (
      0 => '/var/www/sugarcrm/core/general/module/views/templates/viewContent.tpl',
      1 => 1696698883,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6521920883d177_93005213 (Smarty_Internal_Template $_smarty_tpl) {
?><h4 class="text-center">Home!</h4><?php }
}
