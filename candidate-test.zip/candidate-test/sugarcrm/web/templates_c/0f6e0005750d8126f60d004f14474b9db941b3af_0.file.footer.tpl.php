<?php
/* Smarty version 4.3.4, created on 2023-10-08 12:05:08
  from '/var/www/sugarcrm/core/general/views/templates/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65229af4c4ac50_10423241',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0f6e0005750d8126f60d004f14474b9db941b3af' => 
    array (
      0 => '/var/www/sugarcrm/core/general/views/templates/footer.tpl',
      1 => 1696766703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65229af4c4ac50_10423241 (Smarty_Internal_Template $_smarty_tpl) {
?>        </div>
        <?php echo '<script'; ?>
 src="/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    </body>
</html><?php }
}
