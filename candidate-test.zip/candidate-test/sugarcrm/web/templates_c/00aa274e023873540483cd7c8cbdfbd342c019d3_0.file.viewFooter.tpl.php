<?php
/* Smarty version 4.3.4, created on 2023-10-07 17:00:23
  from '/var/www/sugarcrm/core/general/module/views/templates/viewFooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65218ea76f8b77_42477931',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '00aa274e023873540483cd7c8cbdfbd342c019d3' => 
    array (
      0 => '/var/www/sugarcrm/core/general/module/views/templates/viewFooter.tpl',
      1 => 1696698011,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65218ea76f8b77_42477931 (Smarty_Internal_Template $_smarty_tpl) {
?>        </div>
    </body>
</html><?php }
}
