<?php

global $moduleVardefs;

$moduleVardefs = [];

require_once(__DIR__ . '/../../../web/modules/lt_case/vardefs.php');
require_once(__DIR__ . '/../../../web/modules/lt_policy/vardefs.php');
require_once(__DIR__ . '/../../../web/modules/lt_customer/vardefs.php');
